def draw_circle(radius, color, x, y):
    circ = Circle(radius)
    circ.set_color(color)
    circ.set_position(x, y)
    add(circ)
    
def background():
    draw_circle(1500, Color.black, 1000, 1000)

def draw_scene1():
    print("Many years ago, Mars was a prospering planet")
    background()
    draw_circle(90, Color.yellow, 80, 50)
    draw_circle(50, Color.green, 350, 220)
    draw_circle(40, Color.gray, 50, 200)
    draw_circle(40, Color.blue, get_width()/2, get_height()/2.2)


""" 
 Draws the second scene on the canvas and outputs the second
 section of text for the story.
"""
def draw_scene2():
    print("One day, however, there was a mass extinction that caused the planet to die off and get turned to dust")
    draw_circle(90, Color.yellow, 80, 50)
    draw_circle(50, Color.red, 350, 220)
    draw_cricle(40, Color.gray, 50, 200)
    draw_circle(40, Color.blue, get_width()/2, get_height()/2.2)


""" 
 Draws the third scene on the canvas and outputs the second
 section of text for the story.
"""
def draw_scene3():
    print("All while an asteroid gets caught in the Earth's gravitational pull")
    draw_circle(90, Color.yellow, 80, 50)
    draw_circle(50, Color.green, 350, 220)
    draw_circle(40, Color.gray, 50, 200)
    
    draw_circle(40, Color.blue, get_width()/2, get_height()/2.2)
    draw_circle(100, Color.purple, 400, 50)


""" 
 Draws the fourth scene on the canvas and outputs the second
 section of text for the story.
"""
def draw_scene4():
    print("Giving us our solar system... but something else looms near")
    draw_circle(15, Color.gray, 250, 170)


"""
 This is set up code that makes the story advance from
 scene to scene. Feel free to check out this code and
 learn how it works!
 But be careful! If you modify this code the story might
 not work anymore.
"""

scene_counter = 0

# When this function is called the next scene is drawn.

def draw_next_screen(x, y):
    global scene_counter
    scene_counter += 1

    if scene_counter == 1:
        draw_scene1()
    elif scene_counter == 2:
        draw_scene2()
    elif scene_counter == 3:
        draw_scene3()
    else:
        draw_scene4()

welcome = Text("Click to Begin!")
welcome.set_position(get_width() / 2 - welcome.get_width() / 2, get_height() / 2)
add(welcome)

add_mouse_click_handler(draw_next_screen)
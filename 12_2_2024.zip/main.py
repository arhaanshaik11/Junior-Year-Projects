print('Hello world')

"""immutable_tuple = (6, 7, 8)
print (immutable_tuple)

immutable_tuple = immutable_tuple[:2]
print (immutable_tuple)

empty_tuple = ()
print(empty_tuple[0])"""



"""immutable_string = "abcde"
print(immutable_string)

print(immutable_string)"""

"""my_list = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
print(my_list)
my_list[5] = 16
print(my_list)"""


"""immutable_string = "abcde"
make_my_string_a_list = list(immutable_string)
print(make_my_string_a_list)"""


"""string_from_list = "".join(list_name)
crazy_string = "@".join(make_my_string_a_list)
print(crazy_string)"""


"""my_tuple = [1, 2, 3, "abc"]

for element in my_tuple:
    print(element)"""
    
    
"""watching_waiting = ["Phineus", "Ferb", "Candace"]

for i, name in enumerate(watching_waiting):
    print(str(i) + ": " + name)"""


"""list_with_tuple[2] = (4, 5)
print(list_with_tuple)"""

"""tuple_with_list = (1, 2, [3, 4])
print(tuple_with_list)

tuple_with_list[2][0]=30
print(tuple_with_list)"""


"""my_list = [1, 3, 5, 2, 6, 2, 1, 3, 2, 9, 2]
number_of_twos = my_list.count(2)

print (number_of_twos)"""

"""new_list = [1, 2, 3]
new_list.append(4)

print(new_list)
new_list.append(['a', "b", "c"])

print(new_list)"""




"""short_list = [1, 2, 3]
short_list.extend(["a", "b", "c"])

print(short_list)"""


"""long_list = [1, 2, 3, "a", "b", "c"]
long_list.remove(2)
print(long_list)


list_of_duplicates = [1, 2, 3, 1, 2, 3]
list_of_duplicates.remove(2)

print(list_of_duplicates)

sorting_list = [1, 2, 3, 1, 2, 3, 1, 4]
sorting_list.sort()

print(sorting_list)


string_sorting = ["A", "b", "C", "a", "c", "B"]
string_sorting.sort()

print(string_sorting)"""


my_list = [1, 2, 3, 1, 2]
my_list.reverse()

print(my_list)
"""import random
roll = random.randint (1,6)
print("You rolled a " + str(roll))"""

"""import random
dinner = random.choice(["Mac N Cheese",
"Chicken Nuggets", "Grilled Cheese & Tomato Soup"])
print("Dinner tonight is: " + dinner)"""

import random
is_heads = random.choice([True, False])
print("You flipped heads: " + str(is_heads))
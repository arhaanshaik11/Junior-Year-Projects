print('Hello world')

"""def exclamations(text):
    my_list = list(text)
    my_list = [ "!" if letter == "i" else letter for letter in my_list]
    new_string = "".join(my_list)
print(exclamations("This is not a for loop!"))"""

"""def exclamations_two(text):
    my_list = list(text)
    for inggd, char in enumerate(my_list):
        if char == "i":
            my_list[inggd] = "!"
    text = "".join(my_list)
    return text


print(exclamations_two("I like dogs"))"""



crazy_2 = "apapapapa"
str_split = crazy_2.split("p",4)
print(str_split)

str_split_2 = crazy_2.split("p",3)
print(str_split_2)

str_split_3 = crazy_2.split("p",2)
print(str_split_3)
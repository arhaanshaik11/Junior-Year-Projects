"""print('Hello world')
input1 = True
input2 = True
expression = not(input1) or not (input2)
print(expression)""" #question 63


"""def substring(string, start, end):
    substring = string[start-1:end]
    return(substring)

print(substring("wildcat", 5, 7))

def concat(string1, string2):
    concat = string1+string2
    return(concat)
print (concat("taco", "cat"))

def length(string):
    length = len(string)
    return(length)
    
print (length("bearcat"))

oldStr = "catfish"
n=5
newStr = substring(oldStr, n+1, len(oldStr))
newStr = concat(newStr, substring(oldStr, 1, n-1))"""

#question 70
"""answer_a = [50, 50, 50, 50, 50, 50]

def test_loop(my_list):
    j = len(my_list) - 1
    while True:
        if my_list[j] == my_list[j-1]:
            my_list.remove(my_list[j])
        j = j - 1
        if j == 2:
            break
    return(my_list)

print (test_loop(answer_a))"""

#Q66
"""def answer_a(timer, bonus):
    if timer >= 30:
        bonus = bonus + 500
    if timer > 60:
        bonus = bonus + 500
    return(bonus)
print(answer_a(61, 500))"""

utensils = ["fork", "spoon", "tongs", "spatula", "whisk"]

length = len(utensils)-1
print(length)
print(utensils[length])
temp = utensils[length]
utensils.remove(utensils[length])
utensils.insert(0, temp)
print(utensils)
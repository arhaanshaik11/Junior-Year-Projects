import math

#These are shortcuts to the functions of the program.
print("Welcome to the Calc!")
print("")
print("1. Add")
print("2. Subtract")
print("3. Multiply")
print("4. Divide")
print("5. Quit")
print("")

"""Function that takes in parameter "num_list" and outputs a return
value that correlates with the answer of what equation the
user has requested."""

def do_math(num_list):
    answer = num_list[0]
    #used for addition
    if num_list[1] == "1" or num_list[1] == "+":
        answer += num_list[2]
    
    #used for subtraction
    elif num_list[1] == "2" or num_list[1] == "-":
        answer -= num_list[2]
    
    #used for multiplication        
    elif num_list[1] == "3" or num_list[1] == "x" or num_list[1] == "*":
        num_add = 0
        for i in range(int(answer)):
            num_add += num_list[2]
        answer = num_add
        """answer *= num_list[2]"""
    #used for division    
    elif num_list[1] == "4" or num_list[1] == "/":
        answer /= num_list[2]
    
    else:
        print("Not a valid statement. Please insert a valid number")
            
    return answer
   
#Gets the first input number of the equation from the user.
first_num = float(input("Enter the first number: "))

#Creates list with the first number of the equation
num_list = [first_num]


while True:
    operation = input("What is your operation?: ")
    if operation == "stop" or operation == "5":
        print("")
        print ("Thank you for using the Calc!")
        break

    #Adds numbers onto the starting list.
    else:
        num_list.append(operation)
        next_num = float(input("Enter your next number: "))
        num_list.append(next_num)
    
    #If user types in the number five, the program will stop.
    if num_list[1] == "5":
        break
    
    #Calculates the equation and replaces old list with new answer and repeats
    #same process.
    num_list = [do_math(num_list)]
    print(num_list[0])